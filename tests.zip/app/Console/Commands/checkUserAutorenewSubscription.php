<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Models\User;
use DateTime;
use Carbon\Carbon;
use Illuminate\Support\Facades\Crypt;
use App\Models\Ipn;

class checkUserAutorenewSubscription extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'app:check-user-autorenew-subscription';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'This command for cancel subscription those agent auto_renew subscription off';

    /**
     * Execute the console command.
     */

    public function handle()
    {
        // Set the default timezone to America/Phoenix
        date_default_timezone_set("America/Phoenix");

        // Get the current date and time
        $today = now();

        // Get users with expired subscriptions of type 'user'
        $users = User::subscriptionExpired($today)
            ->ofType('subscriber')
            ->get();

        // Loop through each user with expired subscription
        foreach ($users as $user) {

            // Display information about the canceled subscription
            $this->info($user->id . ' subscription is cancel');

            // Get the name of the current plan for the user
            $current_plan_user = $user->activeSubsription->plan->name;

            // Prepare data for email notification
            $data = [
                'data' => [
                    'email'               => $user->email,
                    'last_name'           => $user->last_name,
                    'first_name'          => $user->first_name,
                    'old_subscription'    => $current_plan_user,
                    'current_subcription' => 'Free'
                ]
            ];

            // Remove user data and update membership details
            $user->removeUserData($user);

            // Get IPN entries for the user
            $ipn = Ipn::where('user_id', $user->id)->pluck('id');

            // Check if there are IPN entries for the user
            if ($ipn->isNotEmpty()) {
                // Deactivate IPN entries for the user
                Ipn::whereIn('id', $ipn)->update(['current_membership' => 'deactive']);
            }

            // Create a new IPN entry for the user
            Ipn::create([
                'user_id'            => $user->id,
                'customer_id'        => "ckd_" . $user->id,
                'status'             => 'done',
                'type'               => 'authorized',
                'current_membership' => 'active'
            ]);

            // $this->mailSendCommonV2($data, 'auto_cancel_subscription');
        }
    }
}
