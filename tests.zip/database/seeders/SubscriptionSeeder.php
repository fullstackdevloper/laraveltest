<?php
namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\User;
use App\Models\Plan;
use App\Models\Subscription;

class SubscriptionSeeder extends Seeder
{
    public function run()
    {
        $users = User::all();
        $plans = Plan::all();

        foreach ($users as $user) {
            $plan      = $plans->random();
            $isMonthly = strpos($plan->name, 'Monthly') !== false;
            $startDate = now();
            $endDate = $isMonthly ? $startDate->addMonth() : $startDate->addYear();

            Subscription::create([
                'user_id'    => $user->id,
                'plan_id'    => $plan->id,
                'start_date' => $startDate,
                'end_date'   => $endDate,
            ]);
        }
    }
}

